const form = document.getElementById("studentForm");
const table = document.getElementById("studentTable");
const search = document.getElementById("search");

let students = JSON.parse(localStorage.getItem("students")) || [];

function saveStudents() {
    localStorage.setItem("students", JSON.stringify(students));
}

function displayStudents(list = students) {
    table.innerHTML = "";

    if (list.length === 0) {
        table.innerHTML = '<tr><td colspan="5">No student records found.</td></tr>';
        return;
    }

    list.forEach((student, index) => {
        const row = document.createElement("tr");
        row.innerHTML = `
            <td>${student.name}</td>
            <td>${student.roll}</td>
            <td>${student.branch}</td>
            <td>${student.marks}</td>
            <td>
                <button class="delete-btn" onclick="deleteStudent(${index})">Delete</button>
            </td>
        `;
        table.appendChild(row);
    });
}

form.addEventListener("submit", function(event) {
    event.preventDefault();

    const student = {
        name: document.getElementById("name").value.trim(),
        roll: document.getElementById("roll").value.trim(),
        branch: document.getElementById("branch").value.trim(),
        marks: document.getElementById("marks").value
    };

    students.push(student);
    saveStudents();
    displayStudents();
    form.reset();
});

function deleteStudent(index) {
    students.splice(index, 1);
    saveStudents();
    displayStudents();
}

search.addEventListener("input", function() {
    const query = search.value.toLowerCase();

    const filtered = students.filter(student =>
        student.name.toLowerCase().includes(query) ||
        student.roll.toLowerCase().includes(query)
    );

    displayStudents(filtered);
});

displayStudents();
