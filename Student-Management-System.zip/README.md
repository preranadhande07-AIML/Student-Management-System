# Student Management System

## About the Project
A simple web-based Student Management System created using HTML, CSS, and JavaScript.

## Features
- Add student records
- Store student name, roll number, branch, and marks
- Search students by name or roll number
- Delete student records
- Data is saved in the browser using localStorage
- Responsive interface

## Technologies Used
- HTML5
- CSS3
- JavaScript

## How to Run
1. Download or clone the repository.
2. Open `index.html` in a web browser.
3. Add and manage student records.

## Git Commands Used
```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin YOUR_GITHUB_REPOSITORY_URL
git push -u origin main
```
